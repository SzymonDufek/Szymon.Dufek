#!/bin/bash
DATA="22.01.2021-13:17"
mkdir kopia-home-"$DATA"
mkdir zad2
cd zad2
mkdir s96428
cd s96428
echo "$DATA, zad2, s96428" >> log.txt
